import type { ApiConfig, CaseData } from "../types";
import { CASES } from "../data/cases";
import { isConfigReady } from "../lib/model";
import CaseCard from "./CaseCard";

interface Props {
  apiConfig: ApiConfig;
  onSelectCase: (c: CaseData) => void;
  onOpenApi: () => void;
}

export default function HomePage({ apiConfig, onSelectCase, onOpenApi }: Props) {
  const ready = isConfigReady(apiConfig);

  return (
    <div className="home">
      <header className="home-header">
        <div className="brand">
          <span className="brand-mark" aria-hidden="true" />
          <span className="brand-name">DETECTIVE AGENT</span>
        </div>
        <button className={`btn btn-ghost api-btn ${ready ? "is-ready" : ""}`} onClick={onOpenApi}>
          {ready && <span className="check-mark" aria-hidden="true" />}
          {ready ? "DeepSeek 已连接" : "填写 DeepSeek Key"}
        </button>
      </header>

      <section className="hero">
        <p className="hero-kicker">AGENT LOOP · 观察 / 决策 / 行动 / 评估</p>
        <h1 className="hero-title">
          AI 侦探<span className="hero-title-accent">推理档案</span>
        </h1>
        <p className="hero-desc">
          选择一桩悬案，下达调查指令。AI 侦探将自主审问嫌疑人、检查物证、交叉比对证词矛盾，
          在每一轮循环中推理、行动、评估，直到指认真凶。没有 API 也可以使用演示模式观看完整调查流程。
        </p>
      </section>

      <section className="case-section">
        <div className="section-head">
          <h2 className="section-title">案件卷宗</h2>
          <span className="section-sub">共 {CASES.length} 宗待破悬案</span>
        </div>
        <div className="case-grid">
          {CASES.map((c, i) => (
            <CaseCard key={c.id} caseData={c} index={i} onClick={() => onSelectCase(c)} />
          ))}
        </div>
      </section>

      <footer className="home-footer">
        由 DeepSeek（deepseek-chat）驱动 · API Key 仅保存在本地浏览器
      </footer>
    </div>
  );
}
