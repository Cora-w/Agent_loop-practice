import { useState } from "react";
import type { AgentStatus, ApiConfig, CaseData } from "../types";
import { useAgentLoop } from "../hooks/useAgentLoop";
import { DEEPSEEK_MODEL, isConfigReady } from "../lib/model";
import CasePanel from "./CasePanel";
import InstructionInput from "./InstructionInput";
import LoopIndicator from "./LoopIndicator";
import Timeline from "./Timeline";
import ClueBoard from "./ClueBoard";

interface Props {
  caseData: CaseData;
  apiConfig: ApiConfig;
  onBack: () => void;
  onOpenApi: (hint?: string) => void;
}

const STATUS_TEXT: Record<AgentStatus, string> = {
  idle: "待命",
  running: "调查中",
  success: "已结案",
  error: "已中断",
};

export default function InvestigatePage({ caseData, apiConfig, onBack, onOpenApi }: Props) {
  const loop = useAgentLoop(caseData);
  const [instruction, setInstruction] = useState("");
  const running = loop.status === "running";

  const resolveGoal = () => instruction.trim() || caseData.goal;

  const handleStart = () => {
    if (running) return;
    if (!isConfigReady(apiConfig)) {
      onOpenApi("开始调查前，请先填写 DeepSeek API Key。");
      return;
    }
    void loop.start(resolveGoal(), apiConfig);
  };

  const handleDemo = () => {
    if (running) return;
    void loop.startDemo(resolveGoal());
  };

  const handleBack = () => {
    loop.reset();
    onBack();
  };

  const accused = loop.verdict?.accused ?? null;

  return (
    <div className="investigate">
      <header className="inv-header">
        <button className="btn btn-ghost back-btn" onClick={handleBack}>
          <span aria-hidden="true">←</span> 返回案件
        </button>
        <div className="inv-title">
          <span className="inv-title-icon">{caseData.icon}</span>
          <h1>{caseData.title}</h1>
          <span className="inv-difficulty">{caseData.difficulty}</span>
        </div>
        <div className="inv-header-right">
          {loop.mode && (
            <span className="mode-tag">{loop.mode === "demo" ? "演示模式" : DEEPSEEK_MODEL}</span>
          )}
          <div className={`status-indicator status-${loop.status}`}>
            <span className="status-dot" />
            <span>{STATUS_TEXT[loop.status]}</span>
            {loop.currentStep > 0 && <span className="status-step">STEP {loop.currentStep}</span>}
          </div>
        </div>
      </header>

      <div className="inv-grid">
        <aside className="inv-col inv-left">
          <CasePanel caseData={caseData} accused={accused} />
        </aside>

        <main className="inv-col inv-center">
          <InstructionInput
            value={instruction}
            onChange={setInstruction}
            onStart={handleStart}
            onDemo={handleDemo}
            onStop={loop.stop}
            status={loop.status}
            hasRun={loop.steps.length > 0}
            apiReady={isConfigReady(apiConfig)}
            onOpenApi={() => onOpenApi()}
          />
          <LoopIndicator phase={loop.phase} step={loop.currentStep} running={running} />
          <Timeline
            caseData={caseData}
            steps={loop.steps}
            status={loop.status}
            goal={loop.goal}
            verdict={loop.verdict}
            finalAnswer={loop.finalAnswer}
            error={loop.error}
          />
        </main>

        <aside className="inv-col inv-right">
          <ClueBoard clues={loop.clues} />
        </aside>
      </div>
    </div>
  );
}
