import type { AgentStatus } from "../types";

interface Props {
  value: string;
  onChange: (v: string) => void;
  onStart: () => void;
  onDemo: () => void;
  onStop: () => void;
  status: AgentStatus;
  hasRun: boolean;
  apiReady: boolean;
  onOpenApi: () => void;
}

const SUGGESTIONS = [
  { label: "全面调查", text: "全面调查此案，不放过任何细节，找出真凶" },
  { label: "先审后查", text: "先审问所有嫌疑人，再检查物证，找出说谎的人" },
  { label: "排查时间线", text: "重点排查每个人的不在场证明和时间线" },
  { label: "从动机查起", text: "从动机入手，谁最有理由犯案就先查谁" },
];

export default function InstructionInput({
  value,
  onChange,
  onStart,
  onDemo,
  onStop,
  status,
  hasRun,
  apiReady,
  onOpenApi,
}: Props) {
  const running = status === "running";
  const finished = !running && hasRun;

  return (
    <section className="instruction">
      <div className="instruction-head">
        <div>
          <h2 className="instruction-title">调查指令</h2>
          <p className="instruction-hint">输入你希望侦探采取的调查策略，或点击下方推荐</p>
        </div>
        <button className={`api-pill ${apiReady ? "is-ready" : ""}`} onClick={onOpenApi} type="button">
          <span className="ready-dot" />
          {apiReady ? "DeepSeek 已连接" : "未填写 Key"}
        </button>
      </div>

      <div className="instruction-row">
        <input
          className="text-input instruction-input"
          placeholder="例如：先审问所有嫌疑人，然后逐一检查物证，找出证词中的矛盾"
          value={value}
          disabled={running}
          onChange={(e) => onChange(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === "Enter" && !e.nativeEvent.isComposing) onStart();
          }}
        />
        {running ? (
          <button className="btn btn-danger" onClick={onStop}>
            中止调查
          </button>
        ) : (
          <button className="btn btn-primary" onClick={onStart}>
            {finished ? "重新调查" : "开始调查"}
          </button>
        )}
        <button className="btn btn-outline" onClick={onDemo} disabled={running}>
          演示模式
        </button>
      </div>

      <div className="chips">
        {SUGGESTIONS.map((s) => (
          <button
            key={s.label}
            type="button"
            className={`chip ${value === s.text ? "is-active" : ""}`}
            disabled={running}
            onClick={() => onChange(s.text)}
            title={s.text}
          >
            {s.label}
          </button>
        ))}
      </div>
    </section>
  );
}
