import type { Action, AgentContext, ApiConfig, CaseData, ModelResponse } from "../types";
import { TOOL_DEFINITIONS, toolResultToText } from "./tools";

export const SYSTEM_PROMPT =
  "你是一名资深刑侦侦探。工作方式：1.getCaseOverview 2.interrogateWitness逐个审问 3.examineEvidence检查物证 4.crossCheckStatements交叉比对 5.reviewClues回顾 6.makeAccusation指认。规则：每次只调一个工具，基于证据推理，注意证词矛盾，指认时给出完整推理链条：动机+机会+证据+排除其他人。";

// ---------------- OpenAI 兼容格式的消息类型 ----------------

interface ToolCall {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
}

type ChatMessage =
  | { role: "system" | "user"; content: string }
  | { role: "assistant"; content: string | null; tool_calls?: ToolCall[] }
  | { role: "tool"; tool_call_id: string; content: string };

interface ChatCompletionResponse {
  choices?: {
    message?: {
      content?: string | null;
      reasoning_content?: string | null;
      tool_calls?: ToolCall[];
    };
    finish_reason?: string;
  }[];
  error?: { message?: string };
}

// ---------------- DeepSeek 固定配置 ----------------

export const DEEPSEEK_MODEL = "deepseek-chat";
export const DEEPSEEK_DIRECT_URL = "https://api.deepseek.com/chat/completions";
/** 本地开发 / 预览时走 Vite 代理（见 vite.config.ts），避免浏览器跨域拦截 */
export const DEEPSEEK_PROXY_URL = "/deepseek/chat/completions";

function isLocalHost(): boolean {
  const h = typeof location !== "undefined" ? location.hostname : "";
  return h === "localhost" || h === "127.0.0.1" || h === "::1" || h === "[::1]";
}

export function resolveEndpoint(): string {
  return import.meta.env.DEV || isLocalHost() ? DEEPSEEK_PROXY_URL : DEEPSEEK_DIRECT_URL;
}

export function isConfigReady(c: ApiConfig | null | undefined): c is ApiConfig {
  return !!c && !!c.apiKey.trim();
}

function explainHttpError(status: number, detail: string): string {
  const hints: Record<number, string> = {
    400: "请求格式错误",
    401: "API Key 无效，请检查是否填写正确",
    402: "账户余额不足，请到 DeepSeek 平台充值",
    422: "请求参数错误",
    429: "请求太频繁，请稍后再试",
    500: "DeepSeek 服务器故障，请稍后再试",
    503: "DeepSeek 服务器繁忙，请稍后再试",
  };
  const hint = hints[status] ?? "请求失败";
  return `DeepSeek ${hint}（HTTP ${status}）${detail ? "：" + detail : ""}`;
}

/** 构建消息：system + user(目标+历史步数) + 历史轮次(assistant 带 tool_calls → tool 结果) */
export function buildMessages(caseData: CaseData, context: AgentContext): ChatMessage[] {
  const messages: ChatMessage[] = [
    { role: "system", content: SYSTEM_PROMPT },
    {
      role: "user",
      content:
        `当前案件：《${caseData.title}》\n` +
        `调查目标：${context.goal}\n` +
        `已执行步数：${context.history.length}（上限 16 步）\n` +
        `请在每次调用工具前，用一两句话说明你的推理和下一步打算，然后调用一个工具。` +
        (context.history.length === 0 ? "现在开始调查。" : "请基于已有结果继续调查。"),
    },
  ];

  for (const h of context.history) {
    messages.push({
      role: "assistant",
      content: h.thinking ?? null,
      tool_calls: [
        {
          id: h.toolCallId,
          type: "function",
          function: { name: h.action.tool, arguments: JSON.stringify(h.action.input) },
        },
      ],
    });
    messages.push({ role: "tool", tool_call_id: h.toolCallId, content: toolResultToText(h.result) });
  }
  return messages;
}

function parseArguments(raw: string | undefined): Record<string, string> {
  if (!raw) return {};
  try {
    const obj: unknown = JSON.parse(raw);
    if (!obj || typeof obj !== "object") return {};
    const out: Record<string, string> = {};
    for (const [k, v] of Object.entries(obj as Record<string, unknown>)) {
      out[k] = typeof v === "string" ? v : JSON.stringify(v);
    }
    return out;
  } catch {
    return {};
  }
}

/**
 * 调用模型一次。
 * - 返回 tool_calls → { done:false, action }
 * - 只返回 content → { done:true, answer }
 * - content 同时作为 thinking 通过回调抛出
 */
export async function callModel(
  config: ApiConfig,
  caseData: CaseData,
  context: AgentContext,
  onThinking: (text: string) => void,
  signal?: AbortSignal
): Promise<ModelResponse> {
  let res: Response;
  try {
    res = await fetch(resolveEndpoint(), {
      method: "POST",
      headers: {
        Authorization: `Bearer ${config.apiKey.trim()}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        model: DEEPSEEK_MODEL,
        messages: buildMessages(caseData, context),
        tools: TOOL_DEFINITIONS,
        tool_choice: "auto",
        temperature: 0.7,
        max_tokens: 2048,
      }),
      signal,
    });
  } catch (e) {
    if ((e as { name?: string })?.name === "AbortError") throw e;
    throw new Error(
      isLocalHost()
        ? "无法连接 DeepSeek：本地代理没有响应。请确认是用 npm run dev 启动的，并且电脑能访问 api.deepseek.com。"
        : "无法连接 DeepSeek：当前页面不允许访问外部 API（claude.ai 链接页面就是这种情况）。请在本地 D:\\Agent_loop 运行 npm run dev 后，在 http://localhost:5173 使用。",
      { cause: e }
    );
  }

  if (!res.ok) {
    let detail = "";
    try {
      detail = (await res.text()).slice(0, 300);
    } catch {
      /* ignore */
    }
    throw new Error(explainHttpError(res.status, detail));
  }

  let data: ChatCompletionResponse;
  try {
    data = (await res.json()) as ChatCompletionResponse;
  } catch {
    throw new Error("DeepSeek 返回的内容不是 JSON。请确认是用 npm run dev 启动的（需要 Vite 代理转发请求）。");
  }
  if (data.error?.message) throw new Error(`DeepSeek 返回错误：${data.error.message}`);

  const message = data.choices?.[0]?.message;
  if (!message) throw new Error("DeepSeek 返回格式异常：缺少 choices[0].message");

  const content = (message.content ?? "").trim();
  const reasoning = (message.reasoning_content ?? "").trim();
  const thinking = content || reasoning;
  if (thinking) onThinking(thinking);

  const call = message.tool_calls?.[0];
  if (call?.function?.name) {
    const action: Action = { tool: call.function.name, input: parseArguments(call.function.arguments) };
    return {
      done: false,
      action,
      toolCallId: call.id || `call_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`,
      thinking: thinking || undefined,
    };
  }

  if (content) return { done: true, answer: content, thinking: content };
  throw new Error("模型既没有调用工具也没有返回内容，请重试一次。");
}
