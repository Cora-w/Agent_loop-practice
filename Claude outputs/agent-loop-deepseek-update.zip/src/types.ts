// ===================== 案件数据 =====================

export interface Suspect {
  id: string;
  name: string;
  role: string;
  info: string;
}

export interface Statement {
  personId: string;
  personName: string;
  content: string;
}

export interface Evidence {
  id: string;
  name: string;
  content: string;
}

export interface Contradiction {
  id: string;
  involved: string[];
  finding: string;
}

export interface Truth {
  culprit: string;
  reasoning: string;
}

export interface CaseData {
  id: string;
  title: string;
  icon: string;
  difficulty: string;
  tagline: string;
  brief: string;
  time: string;
  location: string;
  suspects: Suspect[];
  statements: Statement[];
  evidence: Evidence[];
  contradictions: Contradiction[];
  truth: Truth;
  goal: string;
}

// ===================== Agent 运行时 =====================

export interface Action {
  tool: string;
  input: Record<string, string>;
}

export interface ClueItem {
  id: string;
  type: "statement" | "evidence" | "contradiction";
  title: string;
  snippet: string;
}

export interface ToolResult {
  success: boolean;
  result?: string;
  error?: string;
  isFinalAction?: boolean;
  correct?: boolean;
  accused?: string;
  reasoning?: string;
  /** 本次工具调用新产生的线索（用于线索板自动收集） */
  clues?: ClueItem[];
}

export interface TimelineStep {
  step: number;
  thinking?: string;
  action?: Action;
  result?: ToolResult;
}

export type LoopPhase = "observe" | "decide" | "act" | "evaluate" | null;

export type AgentStatus = "idle" | "running" | "success" | "error";

// ===================== 配置 & 模型 =====================

/** 只需要 DeepSeek API Key，地址和模型固定 */
export interface ApiConfig {
  apiKey: string;
}

/** 已完成的一轮：assistant 发起 tool_call → tool 返回结果 */
export interface HistoryEntry {
  step: number;
  thinking?: string;
  action: Action;
  toolCallId: string;
  result: ToolResult;
}

export interface AgentContext {
  goal: string;
  history: HistoryEntry[];
}

export interface ModelResponse {
  done: boolean;
  action?: Action;
  toolCallId?: string;
  answer?: string;
  thinking?: string;
}

export interface LoopOutcome {
  success: boolean;
  steps: number;
  finalResult?: ToolResult;
  answer?: string;
  reason?: string;
}

export type Page = "home" | "investigate";

export type RunMode = "api" | "demo";
