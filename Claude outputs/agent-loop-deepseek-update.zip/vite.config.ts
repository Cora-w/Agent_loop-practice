import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// DeepSeek 不允许浏览器直接跨域调用，本地开发和预览时通过 Vite 代理转发：
// 浏览器请求 /deepseek/chat/completions → https://api.deepseek.com/chat/completions
const deepseekProxy = {
  '/deepseek': {
    target: process.env.DEEPSEEK_TARGET ?? 'https://api.deepseek.com',
    changeOrigin: true,
    secure: true,
    rewrite: (path: string) => path.replace(/^\/deepseek/, ''),
  },
}

// https://vite.dev/config/
export default defineConfig({
  plugins: [react()],
  server: { proxy: deepseekProxy },
  preview: { proxy: deepseekProxy },
})
